public class SavingsAccount extends Account {

    public SavingsAccount(long accountNumber, double balance) {
        super(accountNumber, balance);
    }
    @Override
    public void withdraw(double x) {

    }

    @Override
    public void deposit(double x) {

    }
}
