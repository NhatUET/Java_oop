public class CheckingAccount extends Account {

    public CheckingAccount(long accountNumber, double balance) {
        super(accountNumber, balance);
    }
    @Override
    public void withdraw(double x) {

    }

    @Override
    public void deposit(double x) {

    }
}
