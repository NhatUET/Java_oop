public class BankException extends Exception {
    public BankException(String e) {
        super(e);
    }
}
