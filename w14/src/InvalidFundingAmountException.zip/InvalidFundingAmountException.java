public class InvalidFundingAmountException extends BankException {

    public InvalidFundingAmountException(String e) {
        super(e);
    }
    // so am
}
