public class InsufficientFundsException extends BankException {

    public InsufficientFundsException(String e) {
        super(e);
    }
    // vuot qua so du
}
